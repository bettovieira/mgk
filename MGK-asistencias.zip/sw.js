/* =========================================================================
   EL QUE HACE QUE LA APP ABRA SIN SEÑAL
   -------------------------------------------------------------------------
   Primero pregunta a la red y, si contesta, esa es la version que se usa y
   se guarda una copia. Si la red no contesta, se abre la copia guardada.
   Asi un tecnico en el sotano de una tienda abre la aplicacion igual, y
   nadie se queda con una version vieja mientras haya señal.

   Lo que va al servidor de Google NO pasa por aqui: es de otro dominio y se
   deja seguir de largo. Una respuesta del servidor guardada en cache seria
   un dato viejo haciendose pasar por nuevo.
   ========================================================================= */
const CAJA = 'mgk-2';

/* Lo que hace falta para que la app se VEA, y no solo para que abra: el
   diseño y la letra de los iconitos. Antes se guardaban recien en la segunda
   visita, y ahi estaba el problema: el trabajador instala la app en la
   oficina, con señal, y la abre por primera vez de verdad en el sotano de una
   tienda. Esa vez tiene que verse bien. */
const IMPRESCINDIBLE = ['./', 'estilos.css', 'iconos.css', 'iconos.woff2'];

self.addEventListener('install', function(e){
  e.waitUntil(
    caches.open(CAJA)
      .then(function(c){ return c.addAll(IMPRESCINDIBLE); })
      /* Instalar sin señal no puede romper la instalacion: lo que falte se
         guarda solo la proxima vez que la app se abra con red. */
      .catch(function(){})
      .then(function(){ return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function(e){
  e.waitUntil(
    caches.keys()
      .then(function(viejas){
        return Promise.all(viejas.filter(function(k){ return k !== CAJA; })
                                 .map(function(k){ return caches.delete(k); }));
      })
      .then(function(){ return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function(e){
  if(e.request.method !== 'GET') return;
  if(new URL(e.request.url).origin !== location.origin) return;
  /* ignoreVary: la copia se guarda desde un fetch normal y esto puede ser
     una navegacion. Sin eso no se reconocen como la misma cosa y la
     pantalla queda en blanco justo cuando mas falta hace. */
  const guardada = function(){ return caches.match(e.request, {ignoreVary:true}); };

  e.respondWith(
    fetch(e.request).then(function(r){
      if(r && r.ok){
        const copia = r.clone();
        e.waitUntil(caches.open(CAJA).then(function(c){ return c.put(e.request, copia); }));
        return r;
      }
      /* Contesto, pero con un error. Eso pasa con una red de tienda que
         devuelve su propia pagina, o cuando el servidor esta caido: una
         pantalla de error donde deberia estar la aplicacion. Si hay copia,
         vale mas la copia. */
      return guardada().then(function(c){ return c || r; });
    }).catch(function(){
      return guardada();
    })
  );
});
